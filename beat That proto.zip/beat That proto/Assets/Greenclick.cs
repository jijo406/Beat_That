﻿using UnityEngine;
using System.Collections;

public class Greenclick : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.Mouse0))
        {
            GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = "Brown";
            cube.GetComponent<Renderer>().material.color = new Color(0.5f, 1, 1);
            cube.transform.position = new Vector3(-4.5F,0,0);
            cube.transform.localScale = new Vector3(4, 4, 0.5F);
        }
    }
}
