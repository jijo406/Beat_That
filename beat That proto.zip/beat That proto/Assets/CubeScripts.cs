﻿using UnityEngine;
using System.Collections;

public class CubeScripts : MonoBehaviour {

    public static Transform[] Cubes;


    void Update()
    {
    Cubes = new Transform[transform.childCount];
        for(int i = 0; i < Cubes.Length; i++)
        {
         
          Cubes[i]=transform.GetChild(i);
          print(Cubes[i]);
        
        }
    }
    
}
